// You can use this program to run experiments
// 1. Add statements inside main
// 2. Compile 
// 3. Right-click on the Test rectangle and select main
// 4. Click Ok on the next dialog
// 5. The output is displayed in a terminal window

public class Test
{
    public static void main(String[] args)
    {
        // Add something inside the ( )
        System.out.println(  );
        // Add more statements below, as needed
    }
}
