// TODO: Print 3 + 4 + 5 and "3 + 4 + 5".
// Complete the program, compile, run, and observe.

public class Test
{
    public static void main(String[] args)
    {
        System.out.println(  );
        System.out.println(  );
    }
}
