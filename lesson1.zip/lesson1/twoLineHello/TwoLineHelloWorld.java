// Look for lines that begin with two slashes! These are "comments" and 
// we will use them to let you know what you should do on each programming
// exercise. Have fun!

public class TwoLineHelloWorld
{
    public static void main(String args[])
    {
        // Write your code to print "Hello" and "World" on separate lines below
        // Hint: You can use System.out.println("your text here");
        // Hint2: You want to use System.out.println twice. Once to print "Hello" and a second time to print "World" 
    }
}
